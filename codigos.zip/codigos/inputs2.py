# 1% das vendas
vendas = input("Digite suas vendas do dia:")
vendas = float(vendas)

bonus = vendas * 0.01
print(bonus)

# cuidado
vendas_dia1 = input("Vendas Dia 1:")
vendas_dia2 = input("Vendas Dia 2:")

print(f"Total de Vendas {float(vendas_dia1) + float(vendas_dia2)}")
